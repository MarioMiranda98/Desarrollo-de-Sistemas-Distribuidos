public class Error {
	String message;

	public Error(String message) {
		this.message = message;
	}
}